
# Simple shell script to compile Java-classes that are part 
# of the jabref-extensions.
# We don't use ant here, 'cause anyone just with a out-of-the-box
# Java-installation should be able to compile
# extension files.
# For Windows there is a corresponding batch-script

echo todo